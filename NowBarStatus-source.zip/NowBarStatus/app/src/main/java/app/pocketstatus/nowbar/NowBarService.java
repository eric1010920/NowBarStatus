package app.pocketstatus.nowbar;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.net.TrafficStats;
import android.os.SystemClock;

import java.util.Locale;

public class NowBarService extends Service {
    static final String CHANNEL = "nowbar_status";
    static final int ID = 1001;
    static final long INTERVAL_MS = 2000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private NotificationManager nm;
    private long lastRx, lastTx, lastTime;
    private boolean started;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            nm.notify(ID, build());
            handler.postDelayed(this, INTERVAL_MS);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(
                CHANNEL, "Now Bar 狀態", NotificationManager.IMPORTANCE_DEFAULT);
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!started) {
            started = true;
            lastRx = TrafficStats.getTotalRxBytes();
            lastTx = TrafficStats.getTotalTxBytes();
            lastTime = SystemClock.elapsedRealtime();
            Notification n = build();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(ID, n);
            }
            handler.postDelayed(tick, INTERVAL_MS);
        }
        return START_STICKY;
    }

    private Notification build() {
        long now = SystemClock.elapsedRealtime();
        long rx = TrafficStats.getTotalRxBytes();
        long tx = TrafficStats.getTotalTxBytes();
        long dt = Math.max(1, now - lastTime);
        long down = Math.max(0, (rx - lastRx) * 1000 / dt);
        long up = Math.max(0, (tx - lastTx) * 1000 / dt);
        lastRx = rx; lastTx = tx; lastTime = now;

        float temp = batteryTempC();
        String tempStr = String.format(Locale.US, "%.1f°C", temp);

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
                .setContentTitle("↓ " + speed(down) + "   ↑ " + speed(up))
                .setContentText("電池溫度 " + tempStr)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setContentIntent(pi);

        if (Build.VERSION.SDK_INT >= 36) {
            // Android 16 promoted ongoing notification -> shown as Live notification / Now Bar chip
            b.setRequestPromotedOngoing(true);
            b.setShortCriticalText(speedShort(down) + " " + Math.round(temp) + "°");
        }
        return b.build();
    }

    private float batteryTempC() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return 0f;
        return i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
    }

    private static String speed(long bps) {
        if (bps >= 1024 * 1024) return String.format(Locale.US, "%.1f MB/s", bps / 1048576f);
        return String.format(Locale.US, "%d KB/s", bps / 1024);
    }

    private static String speedShort(long bps) {
        if (bps >= 1024 * 1024) return String.format(Locale.US, "%.1fM", bps / 1048576f);
        return String.format(Locale.US, "%dK", bps / 1024);
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(tick);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
