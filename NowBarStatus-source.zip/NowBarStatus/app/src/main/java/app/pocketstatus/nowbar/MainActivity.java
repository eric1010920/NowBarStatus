package app.pocketstatus.nowbar;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        TextView tv = new TextView(this);
        tv.setText("在 Now Bar 顯示網速與電池溫度\n\n1. 允許通知\n2. 按「啟動」\n3. 若沒出現在 Now Bar，按「Live 通知設定」並開啟");
        tv.setTextSize(16);
        root.addView(tv);

        Button start = new Button(this);
        start.setText("啟動");
        start.setOnClickListener(v -> {
            requestNotif();
            startForegroundService(new Intent(this, NowBarService.class));
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("停止");
        stop.setOnClickListener(v -> stopService(new Intent(this, NowBarService.class)));
        root.addView(stop);

        Button set = new Button(this);
        set.setText("Live 通知設定");
        set.setOnClickListener(v -> openLiveSettings());
        root.addView(set);

        setContentView(root);
        requestNotif();
    }

    private void requestNotif() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private void openLiveSettings() {
        try {
            Intent i = new Intent(Build.VERSION.SDK_INT >= 36
                    ? "android.settings.APP_NOTIFICATION_PROMOTION_SETTINGS"
                    : Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(i);
        } catch (Exception e) {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(i);
        }
    }
}
